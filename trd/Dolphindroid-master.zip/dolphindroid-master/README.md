# dolphindroid
Android UDPWii client

- Emulates the IR sensor using the touchpad
- Able to play commercial games that use the accelerometer just fine
- Supports all default buttons
